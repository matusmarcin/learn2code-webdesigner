<?php
// Your name
$myname = 'Matus Marcin';

// Your email
$myemail = 'me@matusmarcin.com';

// Email subject
$subject = 'Odkaz z portfolia';

// Success message (shown to user)
$success = 'Vaša správa bola odoslaná.';



// Don't edit the code below unless you know what you are doing
if ((isset($_POST['name'])) && (strlen(trim($_POST['name'])) > 0)) {
	$fromname = stripslashes(strip_tags($_POST['name']));
} else {$fromname = 'Nezadali ste meno';}
if ((isset($_POST['email'])) && (strlen(trim($_POST['email'])) > 0)) {
	$fromemail = stripslashes(strip_tags($_POST['email']));
} else {$fromemail = 'Nezadali ste e-mail';}
if ((isset($_POST['message'])) && (strlen(trim($_POST['message'])) > 0)) {
	$message = stripslashes(strip_tags($_POST['message']));
} else {$message = 'Nenapísali ste správu';}

$body = '<body>
<table width="400" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td style="font-weight:bold; vertical-align:bottom;">From</td>
  </tr>
  <tr>
	<td>' . $fromname . '</td>
  </tr>
  <tr>
    <td style="font-weight:bold; height:30px; vertical-align:bottom;">Email</td>
  </tr>
  <tr>
	<td>' . $fromemail . '</td>
  </tr>
  <tr>
    <td style="font-weight:bold; height:30px; vertical-align:bottom;">Message</td>
  </tr>
  <tr>
	<td>' . $message . '</td>
  </tr>
</table>
</body>';

require_once 'class.phpmailer.php';

$mail = new PHPMailer(true);

try {
  if($_POST['num'] != 'tri') {
    throw new Exception('Pravdepodobne ste robot.');
  }  
  $mail->AddReplyTo($fromemail, $fromname);
  $mail->AddAddress($myemail, $myname);
  $mail->SetFrom($fromemail, $fromname);
  $mail->Subject = $subject;
  $mail->AltBody = 'To view the message, please use an HTML compatible email viewer.';
  $mail->MsgHTML($body);
  $mail->Send();
  echo '<p class="success">' . $success . '</p>';
} catch (phpmailerException $e) {
  echo $e->errorMessage();
} catch (Exception $e) {
  echo $e->getMessage();
}
?>
